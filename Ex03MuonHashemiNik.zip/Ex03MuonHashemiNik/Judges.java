public class Judges {
  String name;
  String likes;
  int age;

  public Judges(String a, String b, int c) {
    name = a;
    likes = b;
    age = c;
  }
  
}